# Benvenuto su Axiom Paths

Questa è la home della raccolta di appunti ed esercizi open source.

## Corsi disponibili
- [Analisi 1](analisi-1/teoria/limiti.md)
- [Algebra Lineare](algebra-lineare/teoria/spazi-vettoriali.md)
- Geometria
