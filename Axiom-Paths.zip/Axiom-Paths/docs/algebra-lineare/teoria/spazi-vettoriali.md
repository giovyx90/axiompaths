# Spazi Vettoriali

Definizione:  
Uno **spazio vettoriale** su un campo $\mathbb{K}$ è una struttura $(V, +, \cdot)$ tale che...
