# Esercizi sui Limiti

**Esempio 1**  
Calcolare:
$$
\lim_{x \to 0} \frac{\sin x}{x}
$$
**Soluzione**: Il limite vale $1$.
